
<!doctype html>
<html lang="id-ID" prefix="og: http://ogp.me/ns# fb: http://ogp.me/ns/fb#">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="profile" href="https://gmpg.org/xfn/11">
<title>Transparansi &#8211; DESA KLAMPOK</title>
<link rel='dns-prefetch' href='//platform-api.sharethis.com' />
<link rel='dns-prefetch' href='//fonts.googleapis.com' />
<link rel='dns-prefetch' href='//s.w.org' />
<link rel="alternate" type="application/rss+xml" title="DESA KLAMPOK &raquo; Feed" href="https://klampok.id/feed/" />
<link rel="alternate" type="application/rss+xml" title="DESA KLAMPOK &raquo; Umpan Komentar" href="https://klampok.id/comments/feed/" />
<link rel="alternate" type="application/rss+xml" title="DESA KLAMPOK &raquo; Transparansi Umpan Kategori" href="https://klampok.id/category/transparansi/feed/" />
<script type="text/javascript">
			window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/11.2.0\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/11.2.0\/svg\/","svgExt":".svg","source":{"concatemoji":"https:\/\/klampok.id\/wp-includes\/js\/wp-emoji-release.min.js?ver=5.1.1"}};
			!function(a,b,c){function d(a,b){var c=String.fromCharCode;l.clearRect(0,0,k.width,k.height),l.fillText(c.apply(this,a),0,0);var d=k.toDataURL();l.clearRect(0,0,k.width,k.height),l.fillText(c.apply(this,b),0,0);var e=k.toDataURL();return d===e}function e(a){var b;if(!l||!l.fillText)return!1;switch(l.textBaseline="top",l.font="600 32px Arial",a){case"flag":return!(b=d([55356,56826,55356,56819],[55356,56826,8203,55356,56819]))&&(b=d([55356,57332,56128,56423,56128,56418,56128,56421,56128,56430,56128,56423,56128,56447],[55356,57332,8203,56128,56423,8203,56128,56418,8203,56128,56421,8203,56128,56430,8203,56128,56423,8203,56128,56447]),!b);case"emoji":return b=d([55358,56760,9792,65039],[55358,56760,8203,9792,65039]),!b}return!1}function f(a){var c=b.createElement("script");c.src=a,c.defer=c.type="text/javascript",b.getElementsByTagName("head")[0].appendChild(c)}var g,h,i,j,k=b.createElement("canvas"),l=k.getContext&&k.getContext("2d");for(j=Array("flag","emoji"),c.supports={everything:!0,everythingExceptFlag:!0},i=0;i<j.length;i++)c.supports[j[i]]=e(j[i]),c.supports.everything=c.supports.everything&&c.supports[j[i]],"flag"!==j[i]&&(c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&c.supports[j[i]]);c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&!c.supports.flag,c.DOMReady=!1,c.readyCallback=function(){c.DOMReady=!0},c.supports.everything||(h=function(){c.readyCallback()},b.addEventListener?(b.addEventListener("DOMContentLoaded",h,!1),a.addEventListener("load",h,!1)):(a.attachEvent("onload",h),b.attachEvent("onreadystatechange",function(){"complete"===b.readyState&&c.readyCallback()})),g=c.source||{},g.concatemoji?f(g.concatemoji):g.wpemoji&&g.twemoji&&(f(g.twemoji),f(g.wpemoji)))}(window,document,window._wpemojiSettings);
		</script>
<style type="text/css">
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
<link rel='stylesheet' id='wp-block-library-css' href='https://klampok.id/wp-includes/css/dist/block-library/style.min.css?ver=5.1.1' type='text/css' media='all' />
<link rel='stylesheet' id='share-this-share-buttons-sticky-css' href='https://klampok.id/wp-content/plugins/sharethis-share-buttons/css/mu-style.css?ver=5.1.1' type='text/css' media='all' />
<link rel='stylesheet' id='wpemfb-lightbox-css' href='https://klampok.id/wp-content/plugins/wp-embed-facebook/templates/lightbox/css/lightbox.css?ver=3.0.5' type='text/css' media='all' />
<link rel='stylesheet' id='news-portal-fonts-css' href='https://fonts.googleapis.com/css?family=Roboto+Condensed%3A300italic%2C400italic%2C700italic%2C400%2C300%2C700%7CRoboto%3A300%2C400%2C400i%2C500%2C700%7CTitillium+Web%3A400%2C600%2C700%2C300&#038;subset=latin%2Clatin-ext' type='text/css' media='all' />
<link rel='stylesheet' id='font-awesome-css' href='https://klampok.id/wp-content/themes/news-portal/assets/library/font-awesome/css/font-awesome.min.css?ver=4.7.0' type='text/css' media='all' />
<link rel='stylesheet' id='lightslider-style-css' href='https://klampok.id/wp-content/themes/news-portal/assets/library/lightslider/css/lightslider.min.css?ver=1.1.6' type='text/css' media='all' />
<link rel='stylesheet' id='news-portal-lite-google-font-css' href='https://fonts.googleapis.com/css?family=Montserrat%3A300%2C400%2C400i%2C500%2C700&#038;subset=latin%2Clatin-ext' type='text/css' media='all' />
<link rel='stylesheet' id='news-portal-parent-style-css' href='https://klampok.id/wp-content/themes/news-portal/style.css?ver=1.0.0' type='text/css' media='all' />
<link rel='stylesheet' id='news-portal-parent-responsive-css' href='https://klampok.id/wp-content/themes/news-portal/assets/css/np-responsive.css?ver=1.0.0' type='text/css' media='all' />
<link rel='stylesheet' id='news-portal-lite-style-css' href='https://klampok.id/wp-content/themes/news-portal-lite/style.css?ver=1.0.0' type='text/css' media='all' />
<style id='news-portal-lite-style-inline-css' type='text/css'>
.category-button.np-cat-3 a{background:#07d300}
.category-button.np-cat-3 a:hover{background:#00a100}
.np-block-title .np-cat-3{color:#07d300}
.category-button.np-cat-11 a{background:#d87a00}
.category-button.np-cat-11 a:hover{background:#a64800}
.np-block-title .np-cat-11{color:#d87a00}
.category-button.np-cat-4 a{background:#00a9e0}
.category-button.np-cat-4 a:hover{background:#0077ae}
.np-block-title .np-cat-4{color:#00a9e0}
.category-button.np-cat-5 a{background:#00a9e0}
.category-button.np-cat-5 a:hover{background:#0077ae}
.np-block-title .np-cat-5{color:#00a9e0}
.site-title a,.site-description{color:#ffffff}
.navigation .nav-links a,.bttn,button,input[type='button'],input[type='reset'],input[type='submit'],.navigation .nav-links a:hover,.bttn:hover,button,input[type='button']:hover,input[type='reset']:hover,input[type='submit']:hover,.widget_search .search-submit,.edit-link .post-edit-link,.reply .comment-reply-link,.np-top-header-wrap,.np-header-menu-wrapper,#site-navigation ul.sub-menu,#site-navigation ul.children,.np-header-menu-wrapper::before,.np-header-menu-wrapper::after,.np-header-search-wrapper .search-form-main .search-submit,.news_portal_slider .lSAction > a:hover,.news_portal_default_tabbed ul.widget-tabs li,.np-full-width-title-nav-wrap .carousel-nav-action .carousel-controls:hover,.news_portal_social_media .social-link a,.np-archive-more .np-button:hover,.error404 .page-title,#np-scrollup,.news_portal_featured_slider .slider-posts .lSAction > a:hover,.home #masthead .np-home-icon a,#masthead .np-home-icon a:hover,#masthead #site-navigation ul li:hover > a,#masthead #site-navigation ul li.current-menu-item > a,#masthead #site-navigation ul li.current_page_item > a,#masthead #site-navigation ul li.current-menu-ancestor > a,.news_portal_lite_featured_slider .slider-posts .lSAction > a:hover{background:#fb7f00}
.home .np-home-icon a,.np-home-icon a:hover,#site-navigation ul li:hover > a,#site-navigation ul li.current-menu-item > a,#site-navigation ul li.current_page_item > a,#site-navigation ul li.current-menu-ancestor > a,.news_portal_default_tabbed ul.widget-tabs li.ui-tabs-active,.news_portal_default_tabbed ul.widget-tabs li:hover{background:#c94d00}
.np-header-menu-block-wrap::before,.np-header-menu-block-wrap::after{border-right-color:#fb7f00}
a,a:hover,a:focus,a:active,.widget a:hover,.widget a:hover::before,.widget li:hover::before,.entry-footer a:hover,.comment-author .fn .url:hover,#cancel-comment-reply-link,#cancel-comment-reply-link:before,.logged-in-as a,.np-slide-content-wrap .post-title a:hover,#top-footer .widget a:hover,#top-footer .widget a:hover:before,#top-footer .widget li:hover:before,.news_portal_featured_posts .np-single-post .np-post-content .np-post-title a:hover,.news_portal_fullwidth_posts .np-single-post .np-post-title a:hover,.news_portal_block_posts .layout3 .np-primary-block-wrap .np-single-post .np-post-title a:hover,.news_portal_featured_posts .layout2 .np-single-post-wrap .np-post-content .np-post-title a:hover,.np-block-title,.widget-title,.page-header .page-title,.np-related-title,.np-post-meta span:hover,.np-post-meta span a:hover,.news_portal_featured_posts .layout2 .np-single-post-wrap .np-post-content .np-post-meta span:hover,.news_portal_featured_posts .layout2 .np-single-post-wrap .np-post-content .np-post-meta span a:hover,.np-post-title.small-size a:hover,#footer-navigation ul li a:hover,.entry-title a:hover,.entry-meta span a:hover,.entry-meta span:hover,.np-post-meta span:hover,.np-post-meta span a:hover,.news_portal_featured_posts .np-single-post-wrap .np-post-content .np-post-meta span:hover,.news_portal_featured_posts .np-single-post-wrap .np-post-content .np-post-meta span a:hover,.news_portal_featured_slider .featured-posts .np-single-post .np-post-content .np-post-title a:hover,.news_portal_lite_featured_slider .featured-posts .np-single-post .np-post-content .np-post-title a:hover,.np-slide-content-wrap .post-title a:hover,.news_portal_featured_posts .np-single-post .np-post-content .np-post-title a:hover,.news_portal_carousel .np-single-post .np-post-title a:hover,.news_portal_block_posts .layout3 .np-primary-block-wrap .np-single-post .np-post-title a:hover{color:#fb7f00}
.navigation .nav-links a,.bttn,button,input[type='button'],input[type='reset'],input[type='submit'],.widget_search .search-submit,.np-archive-more .np-button:hover{border-color:#fb7f00}
.comment-list .comment-body,.np-header-search-wrapper .search-form-main{border-top-color:#fb7f00}
.np-header-search-wrapper .search-form-main:before{border-bottom-color:#fb7f00}
@media (max-width:768px){#site-navigation,.main-small-navigation li.current-menu-item > .sub-toggle i{background:#fb7f00 !important}}
</style>
<script type='text/javascript' src='//platform-api.sharethis.com/js/sharethis.js#property=5b3ed9b0c5ed960011521b03&#038;product=inline-share-buttons-wp'></script>
<script type='text/javascript' src='https://klampok.id/wp-includes/js/jquery/jquery.js?ver=1.12.4'></script>
<script type='text/javascript' src='https://klampok.id/wp-includes/js/jquery/jquery-migrate.min.js?ver=1.4.1'></script>
<script type='text/javascript' src='https://klampok.id/wp-content/plugins/wp-embed-facebook/templates/lightbox/js/lightbox.min.js?ver=3.0.5'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var WEF = {"local":"id_ID","version":"v2.11","fb_id":"","adaptive":"1"};
/* ]]> */
</script>
<script type='text/javascript' src='https://klampok.id/wp-content/plugins/wp-embed-facebook/inc/js/fb.min.js?ver=3.0.5'></script>
<link rel='https://api.w.org/' href='https://klampok.id/wp-json/' />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://klampok.id/xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="https://klampok.id/wp-includes/wlwmanifest.xml" />
<meta name="generator" content="WordPress 5.1.1" />
<style type="text/css">.recentcomments a{display:inline !important;padding:0 !important;margin:0 !important;}</style>
<link rel="icon" href="https://klampok.id/wp-content/uploads/2018/05/cropped-logo-kabupaten-banjarnegara-32x32.png" sizes="32x32" />
<link rel="icon" href="https://klampok.id/wp-content/uploads/2018/05/cropped-logo-kabupaten-banjarnegara-192x192.png" sizes="192x192" />
<link rel="apple-touch-icon-precomposed" href="https://klampok.id/wp-content/uploads/2018/05/cropped-logo-kabupaten-banjarnegara-180x180.png" />
<meta name="msapplication-TileImage" content="https://klampok.id/wp-content/uploads/2018/05/cropped-logo-kabupaten-banjarnegara-270x270.png" />
<style type="text/css" id="wp-custom-css">
			.np-ticker-block{
	margin: 0px 0px !important;
}
.ticker-caption{
	display: none;
}
@media (max-width: 600px){
	.news-ticker-title > a {
		display: block;
		overflow: hidden;
		text-overflow: ellipsis;
		white-space: nowrap;
	}
	.ticker-content-wrapper .post-cats-list, .np-ticker-block .lSActionX{
		display: none !important;
	}
	.np-ticker-block .lSAction a{
		display: none;
	}
	.site-description{
		white-space: pre-line;
	}
}
.np-logo-section-wrapper{
	background-color: #53d022;
	    background-image: url(https://klampok.id/wp-content/uploads/2018/05/lapangan-blk-klampok-1024x447.jpg);
    background-position: center;
}
.site-title a, .site-description {
    text-shadow: 1px 2px 4px black;
}
#histats_counter{
	text-align:center;
}		</style>


<meta property="og:locale" content="id_ID" />
<meta property="og:site_name" content="DESA KLAMPOK" />
<meta property="og:title" content="Transparansi" />
<meta property="og:url" content="https://klampok.id/category/transparansi/" />
<meta property="og:type" content="article" />
<meta property="og:description" content="Transparasi mengenai penggunaan dana desa dan informas desa Klampok" />
<meta property="og:image" content="https://klampok.id/wp-content/uploads/2018/05/logo-kabupaten-banjarnegara.png" />
<meta property="og:image:url" content="https://klampok.id/wp-content/uploads/2018/05/logo-kabupaten-banjarnegara.png" />
<meta property="og:image:secure_url" content="https://klampok.id/wp-content/uploads/2018/05/logo-kabupaten-banjarnegara.png" />

<meta itemprop="name" content="Transparansi" />
<meta itemprop="headline" content="Transparansi" />
<meta itemprop="description" content="Transparasi mengenai penggunaan dana desa dan informas desa Klampok" />
<meta itemprop="image" content="https://klampok.id/wp-content/uploads/2018/05/logo-kabupaten-banjarnegara.png" />
 

<meta name="twitter:title" content="Transparansi" />
<meta name="twitter:url" content="https://klampok.id/category/transparansi/" />
<meta name="twitter:description" content="Transparasi mengenai penggunaan dana desa dan informas desa Klampok" />
<meta name="twitter:image" content="https://klampok.id/wp-content/uploads/2018/05/logo-kabupaten-banjarnegara.png" />
<meta name="twitter:card" content="summary_large_image" />




</head>
<body class="archive category category-transparansi category-5 wp-custom-logo group-blog hfeed right-sidebar fullwidth_layout archive-classic">
<div id="page" class="site">
<div class="np-top-header-wrap"><div class="mt-container"> <div class="np-top-left-section-wrapper">
<div class="date-section">Kamis, Oktober 17, 2019</div>
</div>
<div class="np-top-right-section-wrapper">
</div>
</div></div><header id="masthead" class="site-header" role="banner"><div class="np-logo-section-wrapper"><div class="mt-container"> <div class="site-branding">
<a href="https://klampok.id/" class="custom-logo-link" rel="home" itemprop="url"><img width="34" height="45" src="https://klampok.id/wp-content/uploads/2018/05/cropped-logo-kabupaten-banjarnegara-1.png" class="custom-logo" alt="DESA KLAMPOK" itemprop="logo" /></a>
<p class="site-title"><a href="https://klampok.id/" rel="home">DESA KLAMPOK</a></p>
<p class="site-description">Website Resmi Pemerintah Desa KlampokKec. Purwareja Klampok Kab. Banjarnegara</p>
</div>
<div class="np-header-ads-area">
</div>
</div></div> <div id="np-menu-wrap" class="np-header-menu-wrapper">
<div class="np-header-menu-block-wrap">
<div class="mt-container">
<div class="np-home-icon">
<a href="/" rel="home"> <i class="fa fa-home"> </i> </a>
</div>
<a href="javascript:void(0)" class="menu-toggle hide"> <i class="fa fa-navicon"> </i> </a>
<nav id="site-navigation" class="main-navigation" role="navigation">
<div class="menu-utama-container"><ul id="primary-menu" class="menu"><li id="menu-item-86" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-home menu-item-86"><a href="/">Beranda</a></li>
<li id="menu-item-28" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-28">
                                 <a href="">PROFILE DESA</a>
                              </li>
                              <li id="menu-item-105" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-105">
                                 <a href="">PEMERINTAHAN DESA</a>
                              </li>
                              <li id="menu-item-33" class="menu-item menu-item-type-taxonomy menu-item-object-category current-post-ancestor current-menu-parent current-post-parent menu-item-33">
                                 <a href="">LEMBAGA MASYARAKAT</a>
                              </li>
                              <li id="menu-item-80" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-80">
                                 <a href="/data-desa">DATA DESA</a>
                              </li>
                              <li id="menu-item-80" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-80">
                                 <a href="/tranparansi">TRANPARANSI</a>
                              </li>
                              <li id="menu-item-80" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-80">
                                 <a href="{{ route('login') }}">LOGIN</a>
                              </li>
</ul>

</div>

 </nav>
<div class="np-header-search-wrapper">
<span class="search-main"><i class="fa fa-search"></i></span>
<div class="search-form-main np-clearfix">
<form role="search" method="get" class="search-form" action="https://klampok.id/">
<label>
<span class="screen-reader-text">Cari untuk:</span>
<input type="search" class="search-field" placeholder="Cari &hellip;" value="" name="s" />
</label>
<input type="submit" class="search-submit" value="Cari" />
</form> </div>
</div>
</div>
</div>
</div>
</header>
<div id="content" class="site-content">
<div class="mt-container">
<div id="primary" class="content-area">
<main id="main" class="site-main" role="main">
<header class="page-header">
<h1 class="page-title">Kategori: Transparansi</h1><div class="archive-description"><p>Transparasi mengenai penggunaan dana desa dan informas desa Klampok</p>
</div> </header>
<article id="post-1978" class="post-1978 post type-post status-publish format-standard hentry category-transparansi">
<div class="np-article-thumb">
<a href="https://klampok.id/2019/05/apbdes-tahun-2019-bidang-pembangunan/">
</a>
</div>
<div class="np-archive-post-content-wrapper">
<header class="entry-header">
<h2 class="entry-title"><a href="https://klampok.id/2019/05/apbdes-tahun-2019-bidang-pembangunan/" rel="bookmark">APBDes Tahun 2019 BIDANG PEMBANGUNAN</a></h2> <div class="entry-meta">
<span class="posted-on"> <a href="https://klampok.id/2019/05/apbdes-tahun-2019-bidang-pembangunan/" rel="bookmark"><time class="entry-date published" datetime="2019-05-23T22:51:33+07:00">23/05/2019</time><time class="updated" datetime="2019-05-23T22:51:34+07:00">23/05/2019</time></a></span><span class="byline"> <span class="author vcard"><a class="url fn n" href="https://klampok.id/author/admin/">admin</a></span></span><span class="comments-link"><a href="https://klampok.id/2019/05/apbdes-tahun-2019-bidang-pembangunan/#respond">Leave a Comment<span class="screen-reader-text"> on APBDes Tahun 2019 BIDANG PEMBANGUNAN</span></a></span> </div>
</header>
<div class="entry-content">
<p>Bidang Pembangunan atau infrastruktur dianggarkan dalam APBDes 2019 sebesar Rp. 770.203.000,- atau 42.98% dari total anggaran dalam APBDes Desa Klampok. Anggaran yang ditetapkan ini lebih besar dari realisasi anggaran Bidang Pembangunan tahun 2018 sebesar Rp. 637.170.500,-&nbsp; atau 38.38% dari total anggaran dalam APBDes tahun 2018. Dengan demikian anggaran Bidang Pembangunan pada tahun 2019 ini naik [&hellip;]</p>
<span class="np-archive-more"><a href="https://klampok.id/2019/05/apbdes-tahun-2019-bidang-pembangunan/" class="np-button"><i class="fa fa-arrow-circle-o-right"></i>Selengkapnya</a></span> </div>
<footer class="entry-footer">
</footer>
</div>
</article>
<article id="post-1976" class="post-1976 post type-post status-publish format-standard hentry category-transparansi">
<div class="np-article-thumb">
<a href="https://klampok.id/2019/05/apbdes-tahun-2019-bidang-penyelenggaraan-pemerintahan/">
</a>
</div>
<div class="np-archive-post-content-wrapper">
<header class="entry-header">
<h2 class="entry-title"><a href="https://klampok.id/2019/05/apbdes-tahun-2019-bidang-penyelenggaraan-pemerintahan/" rel="bookmark">APBDes Tahun 2019 BIDANG PENYELENGGARAAN PEMERINTAHAN</a></h2> <div class="entry-meta">
<span class="posted-on"> <a href="https://klampok.id/2019/05/apbdes-tahun-2019-bidang-penyelenggaraan-pemerintahan/" rel="bookmark"><time class="entry-date published" datetime="2019-05-23T22:48:20+07:00">23/05/2019</time><time class="updated" datetime="2019-05-23T22:48:23+07:00">23/05/2019</time></a></span><span class="byline"> <span class="author vcard"><a class="url fn n" href="https://klampok.id/author/admin/">admin</a></span></span><span class="comments-link"><a href="https://klampok.id/2019/05/apbdes-tahun-2019-bidang-penyelenggaraan-pemerintahan/#respond">Leave a Comment<span class="screen-reader-text"> on APBDes Tahun 2019 BIDANG PENYELENGGARAAN PEMERINTAHAN</span></a></span> </div>
</header>
<div class="entry-content">
<p>Dalam APBDes Klampok Tahun Anggaran 2019 Bidang Penyelenggaraan Pemerintahan ditetapkan sebesar Rp. 915.010.000,- atau 48.72% dari total APBDes. Dibandingkan dengan realisasi APBDes Tahun Anggaran 2018, Bidang Penyelenggaraan Pemerintahan secara nilai anggaran memang mengalami kenaikan dari Rp. 823.995.652,- tetapi secara persentase Bidang penyelenggaraan Pemerintahan ini sebenarnya mengalami penurunan 2.2% dari realisasi APBDes Tahun Anggaran 2018 sebesar [&hellip;]</p>
<span class="np-archive-more"><a href="https://klampok.id/2019/05/apbdes-tahun-2019-bidang-penyelenggaraan-pemerintahan/" class="np-button"><i class="fa fa-arrow-circle-o-right"></i>Selengkapnya</a></span> </div>
<footer class="entry-footer">
</footer>
</div>
</article>
<article id="post-1901" class="post-1901 post type-post status-publish format-standard hentry category-transparansi">
<div class="np-article-thumb">
<a href="https://klampok.id/2019/03/apbdes-klampok-ta-2019/">
</a>
</div>
<div class="np-archive-post-content-wrapper">
<header class="entry-header">
<h2 class="entry-title"><a href="https://klampok.id/2019/03/apbdes-klampok-ta-2019/" rel="bookmark">APBDes KLAMPOK TA 2019</a></h2> <div class="entry-meta">
<span class="posted-on"> <a href="https://klampok.id/2019/03/apbdes-klampok-ta-2019/" rel="bookmark"><time class="entry-date published" datetime="2019-03-27T09:58:46+07:00">27/03/2019</time><time class="updated" datetime="2019-03-27T12:49:41+07:00">27/03/2019</time></a></span><span class="byline"> <span class="author vcard"><a class="url fn n" href="https://klampok.id/author/admin/">admin</a></span></span><span class="comments-link"><a href="https://klampok.id/2019/03/apbdes-klampok-ta-2019/#respond">Leave a Comment<span class="screen-reader-text"> on APBDes KLAMPOK TA 2019</span></a></span> </div>
</header>
<div class="entry-content">
<p>APBDes Tahun Anggaran 2019 sudah ditetapkan oleh BPD bersama Pemerintah Desa Klampok. Dengan ditetapkannya APBDes TA 2019 maka kegiatan Pemrintahan Desa Klampok yang terbagi dalam 5 bidang kegiatan sudah bisa mulai dikerjakan, yaitu Bidang Pemerintahan, Bidang Pembangunan, Bidang Pembinaan dan Pemberdayaan Masyarakat dan Bidang Kejadian Tidak Terduga. APBDes Desa Klampok Tahun Anggaran 2019 sebesar Rp. [&hellip;]</p>
<span class="np-archive-more"><a href="https://klampok.id/2019/03/apbdes-klampok-ta-2019/" class="np-button"><i class="fa fa-arrow-circle-o-right"></i>Selengkapnya</a></span> </div>
<footer class="entry-footer">
</footer>
</div>
</article>
<article id="post-1744" class="post-1744 post type-post status-publish format-standard hentry category-transparansi">
<div class="np-article-thumb">
<a href="https://klampok.id/2019/03/serapan-anggaran-apbdes-2018-bidang-kejadian-tidak-terduga/">
</a>
</div>
<div class="np-archive-post-content-wrapper">
<header class="entry-header">
<h2 class="entry-title"><a href="https://klampok.id/2019/03/serapan-anggaran-apbdes-2018-bidang-kejadian-tidak-terduga/" rel="bookmark">Serapan Anggaran APBDes 2018 Bidang Kejadian Tidak Terduga</a></h2> <div class="entry-meta">
<span class="posted-on"> <a href="https://klampok.id/2019/03/serapan-anggaran-apbdes-2018-bidang-kejadian-tidak-terduga/" rel="bookmark"><time class="entry-date published" datetime="2019-03-11T13:39:30+07:00">11/03/2019</time><time class="updated" datetime="2019-03-11T13:40:38+07:00">11/03/2019</time></a></span><span class="byline"> <span class="author vcard"><a class="url fn n" href="https://klampok.id/author/admin/">admin</a></span></span><span class="comments-link"><a href="https://klampok.id/2019/03/serapan-anggaran-apbdes-2018-bidang-kejadian-tidak-terduga/#respond">Leave a Comment<span class="screen-reader-text"> on Serapan Anggaran APBDes 2018 Bidang Kejadian Tidak Terduga</span></a></span> </div>
</header>
<div class="entry-content">
<p>Bidang kegiatan kelima adalah Kejadian Tidak  Terduga yang menyerap anggaran sebesar Rp. 4.029.000,-. Anggaran ini digunakan untuk perbaikan saluran irigasi disebelah SD 4 Klampok yang longsor karena faktor <a href="/cdn-cgi/l/email-protection" class="__cf_email__" data-cfemail="cdb8bea4ace38db7">[email&#160;protected]</a> 2019</p>
<span class="np-archive-more"><a href="https://klampok.id/2019/03/serapan-anggaran-apbdes-2018-bidang-kejadian-tidak-terduga/" class="np-button"><i class="fa fa-arrow-circle-o-right"></i>Selengkapnya</a></span> </div>
<footer class="entry-footer">
</footer>
</div>
</article>
<article id="post-1739" class="post-1739 post type-post status-publish format-standard has-post-thumbnail hentry category-transparansi">
<div class="np-article-thumb">
<a href="https://klampok.id/2019/03/serapan-anggaran-apbdes-2018-bidang-pelayanan-dan-pemberdayaan-masyarakat/">
<img width="1280" height="853" src="https://klampok.id/wp-content/uploads/2019/03/IMG-20180504-WA0012.jpg" class="attachment-full size-full wp-post-image" alt="" srcset="https://klampok.id/wp-content/uploads/2019/03/IMG-20180504-WA0012.jpg 1280w, https://klampok.id/wp-content/uploads/2019/03/IMG-20180504-WA0012-300x200.jpg 300w, https://klampok.id/wp-content/uploads/2019/03/IMG-20180504-WA0012-768x512.jpg 768w, https://klampok.id/wp-content/uploads/2019/03/IMG-20180504-WA0012-1024x682.jpg 1024w" sizes="(max-width: 1280px) 100vw, 1280px" /> </a>
</div>
<div class="np-archive-post-content-wrapper">
<header class="entry-header">
<h2 class="entry-title"><a href="https://klampok.id/2019/03/serapan-anggaran-apbdes-2018-bidang-pelayanan-dan-pemberdayaan-masyarakat/" rel="bookmark">Serapan Anggaran APBDes 2018 BIDANG PELAYANAN DAN PEMBERDAYAAN MASYARAKAT</a></h2> <div class="entry-meta">
<span class="posted-on"> <a href="https://klampok.id/2019/03/serapan-anggaran-apbdes-2018-bidang-pelayanan-dan-pemberdayaan-masyarakat/" rel="bookmark"><time class="entry-date published" datetime="2019-03-11T13:32:54+07:00">11/03/2019</time><time class="updated" datetime="2019-03-12T09:15:54+07:00">12/03/2019</time></a></span><span class="byline"> <span class="author vcard"><a class="url fn n" href="https://klampok.id/author/admin/">admin</a></span></span><span class="comments-link"><a href="https://klampok.id/2019/03/serapan-anggaran-apbdes-2018-bidang-pelayanan-dan-pemberdayaan-masyarakat/#respond">Leave a Comment<span class="screen-reader-text"> on Serapan Anggaran APBDes 2018 BIDANG PELAYANAN DAN PEMBERDAYAAN MASYARAKAT</span></a></span> </div>
</header>
<div class="entry-content">
<p>Bidang ini termasuk yang paling banyak kegiatannya karena berhubungan langsung dengan kegiatan sosial kemasyarakatan yang ada di desa. Bidang Pelayanan dan Pemberdayaan Masyarakat menyerap anggaran sebesar Rp. 152.867.500,-</p>
<span class="np-archive-more"><a href="https://klampok.id/2019/03/serapan-anggaran-apbdes-2018-bidang-pelayanan-dan-pemberdayaan-masyarakat/" class="np-button"><i class="fa fa-arrow-circle-o-right"></i>Selengkapnya</a></span> </div>
<footer class="entry-footer">
</footer>
</div>
</article>
<article id="post-1736" class="post-1736 post type-post status-publish format-standard has-post-thumbnail hentry category-transparansi">
<div class="np-article-thumb">
<a href="https://klampok.id/2019/03/serapan-anggaran-apbdes-bidang-pembangunan/">
<img width="1280" height="853" src="https://klampok.id/wp-content/uploads/2019/03/IMG-20180504-WA0012.jpg" class="attachment-full size-full wp-post-image" alt="" srcset="https://klampok.id/wp-content/uploads/2019/03/IMG-20180504-WA0012.jpg 1280w, https://klampok.id/wp-content/uploads/2019/03/IMG-20180504-WA0012-300x200.jpg 300w, https://klampok.id/wp-content/uploads/2019/03/IMG-20180504-WA0012-768x512.jpg 768w, https://klampok.id/wp-content/uploads/2019/03/IMG-20180504-WA0012-1024x682.jpg 1024w" sizes="(max-width: 1280px) 100vw, 1280px" /> </a>
</div>
<div class="np-archive-post-content-wrapper">
<header class="entry-header">
<h2 class="entry-title"><a href="https://klampok.id/2019/03/serapan-anggaran-apbdes-bidang-pembangunan/" rel="bookmark">Serapan Anggaran APBDes BIDANG PEMBANGUNAN</a></h2> <div class="entry-meta">
<span class="posted-on"> <a href="https://klampok.id/2019/03/serapan-anggaran-apbdes-bidang-pembangunan/" rel="bookmark"><time class="entry-date published" datetime="2019-03-11T13:23:52+07:00">11/03/2019</time><time class="updated" datetime="2019-03-12T09:12:29+07:00">12/03/2019</time></a></span><span class="byline"> <span class="author vcard"><a class="url fn n" href="https://klampok.id/author/admin/">admin</a></span></span><span class="comments-link"><a href="https://klampok.id/2019/03/serapan-anggaran-apbdes-bidang-pembangunan/#respond">Leave a Comment<span class="screen-reader-text"> on Serapan Anggaran APBDes BIDANG PEMBANGUNAN</span></a></span> </div>
</header>
<div class="entry-content">
<p>Bidang Pembangunan atau Infrastruktur selama Tahun Anggaran 2018 menyerap anggaran sebesar Rp. 637.170.500,- yang digunakan untuk</p>
<span class="np-archive-more"><a href="https://klampok.id/2019/03/serapan-anggaran-apbdes-bidang-pembangunan/" class="np-button"><i class="fa fa-arrow-circle-o-right"></i>Selengkapnya</a></span> </div>
<footer class="entry-footer">
</footer>
</div>
</article>
<article id="post-1727" class="post-1727 post type-post status-publish format-standard has-post-thumbnail hentry category-transparansi">
<div class="np-article-thumb">
<a href="https://klampok.id/2019/03/serapan-anggaran-apbdes-bidang-pemerintahan/">
<img width="1280" height="853" src="https://klampok.id/wp-content/uploads/2019/03/IMG-20180504-WA0012.jpg" class="attachment-full size-full wp-post-image" alt="" srcset="https://klampok.id/wp-content/uploads/2019/03/IMG-20180504-WA0012.jpg 1280w, https://klampok.id/wp-content/uploads/2019/03/IMG-20180504-WA0012-300x200.jpg 300w, https://klampok.id/wp-content/uploads/2019/03/IMG-20180504-WA0012-768x512.jpg 768w, https://klampok.id/wp-content/uploads/2019/03/IMG-20180504-WA0012-1024x682.jpg 1024w" sizes="(max-width: 1280px) 100vw, 1280px" /> </a>
</div>
<div class="np-archive-post-content-wrapper">
<header class="entry-header">
<h2 class="entry-title"><a href="https://klampok.id/2019/03/serapan-anggaran-apbdes-bidang-pemerintahan/" rel="bookmark">Serapan Anggaran APBDes : BIDANG PEMERINTAHAN</a></h2> <div class="entry-meta">
<span class="posted-on"> <a href="https://klampok.id/2019/03/serapan-anggaran-apbdes-bidang-pemerintahan/" rel="bookmark"><time class="entry-date published" datetime="2019-03-11T12:56:59+07:00">11/03/2019</time><time class="updated" datetime="2019-03-12T09:13:23+07:00">12/03/2019</time></a></span><span class="byline"> <span class="author vcard"><a class="url fn n" href="https://klampok.id/author/admin/">admin</a></span></span><span class="comments-link"><a href="https://klampok.id/2019/03/serapan-anggaran-apbdes-bidang-pemerintahan/#respond">Leave a Comment<span class="screen-reader-text"> on Serapan Anggaran APBDes : BIDANG PEMERINTAHAN</span></a></span> </div>
</header>
<div class="entry-content">
<p>Bidang Pemerintahan menyerap anggaran sebesar Rp. 823.995.652,-. Dari serapan anggaran Bidang Pemerintahan tersebut Belanja Pegawai sebesar Rp. 732.364.850,- atau 89,81% dari Total Belanja Pegawai APBDes 2018, Belanja Barang dan Jasa sebesar Rp. 69.749.802,- atau 22,06% dan Belanja Modal Rp. 21.881.000,- atau 4,54%.</p>
<span class="np-archive-more"><a href="https://klampok.id/2019/03/serapan-anggaran-apbdes-bidang-pemerintahan/" class="np-button"><i class="fa fa-arrow-circle-o-right"></i>Selengkapnya</a></span> </div>
<footer class="entry-footer">
</footer>
</div>
</article>
<article id="post-1724" class="post-1724 post type-post status-publish format-standard has-post-thumbnail hentry category-transparansi">
<div class="np-article-thumb">
<a href="https://klampok.id/2019/03/serapan-anggaran-apbdes-desa-klampok-tahun-2018/">
<img width="580" height="446" src="https://klampok.id/wp-content/uploads/2019/03/IMG_20190311_123728.jpg" class="attachment-full size-full wp-post-image" alt="" srcset="https://klampok.id/wp-content/uploads/2019/03/IMG_20190311_123728.jpg 580w, https://klampok.id/wp-content/uploads/2019/03/IMG_20190311_123728-300x231.jpg 300w" sizes="(max-width: 580px) 100vw, 580px" /> </a>
</div>
<div class="np-archive-post-content-wrapper">
<header class="entry-header">
<h2 class="entry-title"><a href="https://klampok.id/2019/03/serapan-anggaran-apbdes-desa-klampok-tahun-2018/" rel="bookmark">SERAPAN ANGGARAN APBDes DESA KLAMPOK TAHUN 2018</a></h2> <div class="entry-meta">
<span class="posted-on"> <a href="https://klampok.id/2019/03/serapan-anggaran-apbdes-desa-klampok-tahun-2018/" rel="bookmark"><time class="entry-date published updated" datetime="2019-03-11T12:46:43+07:00">11/03/2019</time></a></span><span class="byline"> <span class="author vcard"><a class="url fn n" href="https://klampok.id/author/admin/">admin</a></span></span><span class="comments-link"><a href="https://klampok.id/2019/03/serapan-anggaran-apbdes-desa-klampok-tahun-2018/#respond">Leave a Comment<span class="screen-reader-text"> on SERAPAN ANGGARAN APBDes DESA KLAMPOK TAHUN 2018</span></a></span> </div>
</header>
<div class="entry-content">
<p>Dalam laporan pertanggungjawaban APBDes TA 2018, Serapan Anggaran terbagi dalam 3 (tiga) pembelanjaan yaitu Belanja Pegawai sebesar Rp. 815.499.850,- Belanja Barang dan Jasa sebesar Rp. 316.202.802,- Belanja Modal sebesar Rp. 482.331.000,- dan Kejadian Tak Terduga sebesar Rp. 4.029.000,-. Ketiga pembelanjaan ini diserap oleh 5 (lima) bidang kegiatan yaitu Bidang Pemerintahan, Bidang Pembangunan, Bidang Pemberdayaan Masyarakat, [&hellip;]</p>
<span class="np-archive-more"><a href="https://klampok.id/2019/03/serapan-anggaran-apbdes-desa-klampok-tahun-2018/" class="np-button"><i class="fa fa-arrow-circle-o-right"></i>Selengkapnya</a></span> </div>
<footer class="entry-footer">
</footer>
</div>
</article>
<article id="post-1704" class="post-1704 post type-post status-publish format-standard has-post-thumbnail hentry category-transparansi">
<div class="np-article-thumb">
<a href="https://klampok.id/2019/03/laporan-realisasi-apbdes-ta-2018-desa-klampok/">
<img width="880" height="600" src="https://klampok.id/wp-content/uploads/2019/03/sedang_1505812262dana-desa.jpg" class="attachment-full size-full wp-post-image" alt="" srcset="https://klampok.id/wp-content/uploads/2019/03/sedang_1505812262dana-desa.jpg 880w, https://klampok.id/wp-content/uploads/2019/03/sedang_1505812262dana-desa-300x205.jpg 300w, https://klampok.id/wp-content/uploads/2019/03/sedang_1505812262dana-desa-768x524.jpg 768w, https://klampok.id/wp-content/uploads/2019/03/sedang_1505812262dana-desa-305x207.jpg 305w" sizes="(max-width: 880px) 100vw, 880px" /> </a>
</div>
<div class="np-archive-post-content-wrapper">
<header class="entry-header">
<h2 class="entry-title"><a href="https://klampok.id/2019/03/laporan-realisasi-apbdes-ta-2018-desa-klampok/" rel="bookmark">Laporan Realisasi APBDes TA 2018 Desa Klampok</a></h2> <div class="entry-meta">
<span class="posted-on"> <a href="https://klampok.id/2019/03/laporan-realisasi-apbdes-ta-2018-desa-klampok/" rel="bookmark"><time class="entry-date published updated" datetime="2019-03-08T08:39:45+07:00">08/03/2019</time></a></span><span class="byline"> <span class="author vcard"><a class="url fn n" href="https://klampok.id/author/admin/">admin</a></span></span><span class="comments-link"><a href="https://klampok.id/2019/03/laporan-realisasi-apbdes-ta-2018-desa-klampok/#respond">Leave a Comment<span class="screen-reader-text"> on Laporan Realisasi APBDes TA 2018 Desa Klampok</span></a></span> </div>
</header>
<div class="entry-content">
<p>PENDAPATAN Dalam neraca APBDes Tahun 2018, Pendapatan ditargetkan sebesar Rp. 1.670.228.000,- yang terdiri dari Pendapatan Asli Desa (PADes) sebesar Rp. 388.750.000,- Pendapatan Transfer Rp. 1.265.178.000,- dan Pendapatan Lain yang Sah sebesar Rp. 16.300.000,- Pendapatan Asli Desa terdiri dari Hasil Usaha Desa yang meliputi Sewa Tanah Desa untuk Kios Terminal, Lelang sawah dan Tanah Bengkok yang [&hellip;]</p>
<span class="np-archive-more"><a href="https://klampok.id/2019/03/laporan-realisasi-apbdes-ta-2018-desa-klampok/" class="np-button"><i class="fa fa-arrow-circle-o-right"></i>Selengkapnya</a></span> </div>
<footer class="entry-footer">
</footer>
</div>
</article>
<article id="post-1619" class="post-1619 post type-post status-publish format-standard has-post-thumbnail hentry category-transparansi">
<div class="np-article-thumb">
<a href="https://klampok.id/2019/01/aset-desa-dan-pengelolaannya/">
<img width="4160" height="3120" src="https://klampok.id/wp-content/uploads/2019/01/IMG20190123101710.jpg" class="attachment-full size-full wp-post-image" alt="" srcset="https://klampok.id/wp-content/uploads/2019/01/IMG20190123101710.jpg 4160w, https://klampok.id/wp-content/uploads/2019/01/IMG20190123101710-300x225.jpg 300w, https://klampok.id/wp-content/uploads/2019/01/IMG20190123101710-768x576.jpg 768w, https://klampok.id/wp-content/uploads/2019/01/IMG20190123101710-1024x768.jpg 1024w, https://klampok.id/wp-content/uploads/2019/01/IMG20190123101710-136x102.jpg 136w" sizes="(max-width: 4160px) 100vw, 4160px" /> </a>
</div>
<div class="np-archive-post-content-wrapper">
<header class="entry-header">
<h2 class="entry-title"><a href="https://klampok.id/2019/01/aset-desa-dan-pengelolaannya/" rel="bookmark">Aset Desa dan Pengelolaannya</a></h2> <div class="entry-meta">
<span class="posted-on"> <a href="https://klampok.id/2019/01/aset-desa-dan-pengelolaannya/" rel="bookmark"><time class="entry-date published updated" datetime="2019-01-29T09:58:55+07:00">29/01/2019</time></a></span><span class="byline"> <span class="author vcard"><a class="url fn n" href="https://klampok.id/author/admin/">admin</a></span></span><span class="comments-link"><a href="https://klampok.id/2019/01/aset-desa-dan-pengelolaannya/#respond">Leave a Comment<span class="screen-reader-text"> on Aset Desa dan Pengelolaannya</span></a></span> </div>
</header>
<div class="entry-content">
<p>Sesuai UU No. 6 Tahun 2014 tenteng Desa, Aset desa adalah barang milik Desa yang berasal dari kekayaan asli desa, dibeli atau diperoleh atas beban Anggaran Pendapatan dan Belanja Desa atau perolehan hak lainnya yang sah. Selain dalam UU Desa, asset desa secara terperinci diatur dalam Peraturan Menteri Dalam Negeri No.1 Tahun 2016 tentang Pengelolaan Aset [&hellip;]</p>
<span class="np-archive-more"><a href="https://klampok.id/2019/01/aset-desa-dan-pengelolaannya/" class="np-button"><i class="fa fa-arrow-circle-o-right"></i>Selengkapnya</a></span> </div>
<footer class="entry-footer">
</footer>
</div>
</article>
<nav class="navigation posts-navigation" role="navigation">
<h2 class="screen-reader-text">Navigasi pos</h2>
<div class="nav-links"><div class="nav-previous"><a href="https://klampok.id/category/transparansi/page/2/">Pos-pos lama</a></div></div>
</nav>
</main>
</div>
<aside id="secondary" class="widget-area" role="complementary">
<section id="wef_widget-2" class="widget widget_wef_widget"><h4 class="widget-title">Facebook Pemdes Klampok</h4><div class="fb-page" data-href="https://www.facebook.com/desaklampokbanjarnegara" data-width="340" data-height="500" data-tabs="" data-hide-cover="false" data-show-facepile="true" data-hide-cta="false" data-small-header="false" data-adapt-container-width="true"></div></section> <section id="recent-posts-2" class="widget widget_recent_entries"> <h4 class="widget-title">Pos-pos Terbaru</h4> <ul>
<li>
<a href="https://klampok.id/2019/09/feskola-2019-kota-lama-yang-nyata/">Feskola 2019, Kota Lama yang Nyata</a>
</li>
<li>
<a href="https://klampok.id/2019/07/pilkades-damai-jadwal-kampanye-dan-nomer-urut-calon/">PILKADES DAMAI : Jadwal Kampanye dan Nomer Urut Calon</a>
</li>
<li>
<a href="https://klampok.id/2019/07/jambore-karang-taruna-kabupaten-banjarnegara-2019-karang-taruna-kresna-jaya-desa-klampok/">JAMBORE KARANG TARUNA KABUPATEN BANJARNEGARA 2019. Karang Taruna Kresna Jaya Desa Klampok</a>
</li>
<li>
<a href="https://klampok.id/2019/07/2134/">HUT KE-73 POLRI : Polsek Purwareja Klampok Tasyakuran bersama Warga Masyarakat</a>
</li>
<li>
<a href="https://klampok.id/2019/07/dpt-daftar-pemilih-tetap-pemilihan-kepala-desa-klampok-2019-2025/">DPT (Daftar Pemilih Tetap) PEMILIHAN KEPALA DESA KLAMPOK 2019-2025</a>
</li>
</ul>
</section><section id="media_video-3" class="widget widget_media_video"><h4 class="widget-title">Video Profil Desa Klampok</h4><div style="width:100%;" class="wp-video"><!--[if lt IE 9]><script>document.createElement('video');</script><![endif]-->
<video class="wp-video-shortcode" id="video-1619-1" preload="metadata" controls="controls"><source type="video/youtube" src="https://youtu.be/dmwh6uLLbzU?_=1" /><a href="https://youtu.be/dmwh6uLLbzU">https://youtu.be/dmwh6uLLbzU</a></video></div></section><section id="metaslider_widget-3" class="widget widget_metaslider_widget"><h4 class="widget-title">Perangkat</h4><div style="max-width: 150px; margin: 0 auto;" class="ml-slider-3-12-1 metaslider metaslider-nivo metaslider-199 ml-slider">
<div id="metaslider_container_199">
<div class='slider-wrapper theme-default'><div class='ribbon'></div><div id='metaslider_199' class='nivoSlider'><img src="https://klampok.id/wp-content/uploads/2019/06/7C937350-799F-4061-9178-5DD9CF8B2CB0-150x250.jpeg" height="250" width="150" data-caption="Kepala Desa" title="7C937350-799F-4061-9178-5DD9CF8B2CB0" alt="" class="slider-199 slide-217" /><img src="https://klampok.id/wp-content/uploads/2018/05/image2-150x250.jpeg" height="250" width="150" data-caption="Sekretaris Desa" title="image2" alt="" class="slider-199 slide-216" /><img src="https://klampok.id/wp-content/uploads/2018/05/image3-150x250.jpeg" height="250" width="150" data-caption="Kepala Urusan Perencanaan" title="image3" alt="" class="slider-199 slide-215" /><img src="https://klampok.id/wp-content/uploads/2018/05/image4-150x250.jpeg" height="250" width="150" data-caption="Kepala Urusan Umum &amp; TU" title="image4" alt="" class="slider-199 slide-214" /><img src="https://klampok.id/wp-content/uploads/2018/05/image5-e1527261018626-150x250.jpeg" height="250" width="150" data-caption="Kepala Urusan Keuangan" title="image5" alt="" class="slider-199 slide-213" /><img src="https://klampok.id/wp-content/uploads/2018/05/image6-150x250.jpeg" height="250" width="150" data-caption="Kepala Seksi Kesejahteraan" title="image6" alt="" class="slider-199 slide-212" /><img src="https://klampok.id/wp-content/uploads/2018/05/image7-e1527261846422-150x250.jpeg" height="250" width="150" data-caption="Kepala Seksi Pemerintahan" title="image7" alt="" class="slider-199 slide-211" /><img src="https://klampok.id/wp-content/uploads/2018/05/image8-150x250.jpeg" height="250" width="150" data-caption="Kepala Seksi Pelayanan" title="image8" alt="" class="slider-199 slide-210" /><img src="https://klampok.id/wp-content/uploads/2018/05/image9-150x250.jpeg" height="250" width="150" data-caption="Kepala Dusun I" title="image9" alt="" class="slider-199 slide-209" /><img src="https://klampok.id/wp-content/uploads/2018/05/image10-150x250.jpeg" height="250" width="150" data-caption="Kepala Dusun II" title="image10" alt="" class="slider-199 slide-208" /><img src="https://klampok.id/wp-content/uploads/2018/05/image11-150x250.jpeg" height="250" width="150" data-caption="Kepala Dusun IV" title="image11" alt="" class="slider-199 slide-207" /><img src="https://klampok.id/wp-content/uploads/2018/05/image12-150x250.jpeg" height="250" width="150" data-caption="Kepala Dusun V" title="image12" alt="" class="slider-199 slide-206" /><img src="https://klampok.id/wp-content/uploads/2018/05/image16-150x250.jpeg" height="250" width="150" data-caption="Staf Urusan Umum" title="image16" alt="" class="slider-199 slide-202" /><img src="https://klampok.id/wp-content/uploads/2018/05/image13-150x250.jpeg" height="250" width="150" data-caption="Staf Urusan Perencanaan" title="image13" alt="" class="slider-199 slide-205" /><img src="https://klampok.id/wp-content/uploads/2018/05/image15-150x250.jpeg" height="250" width="150" data-caption="Staf Seksi Pelayanan" title="image15" alt="" class="slider-199 slide-203" /><img src="https://klampok.id/wp-content/uploads/2018/05/image14-150x250.jpeg" height="250" width="150" data-caption="Staf Seksi Kesejahteraan" title="image14" alt="" class="slider-199 slide-204" /><img src="https://klampok.id/wp-content/uploads/2018/05/image17-150x250.jpeg" height="250" width="150" data-caption="Pekerja Desa" title="image17" alt="" class="slider-199 slide-201" /><img src="https://klampok.id/wp-content/uploads/2018/05/image18-150x250.jpeg" height="250" width="150" data-caption="Pekerja Desa" title="image18" alt="" class="slider-199 slide-200" /></div></div>
</div>
</div></section><section id="custom_html-2" class="widget_text widget widget_custom_html"><div class="textwidget custom-html-widget">

<div id="histats_counter"></div>
<script data-cfasync="false" src="/cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script type="text/javascript">var _Hasync= _Hasync|| [];
_Hasync.push(['Histats.start', '1,4074658,4,15,170,40,00011011']);
_Hasync.push(['Histats.fasi', '1']);
_Hasync.push(['Histats.track_hits', '']);
window.addEventListener('load', function(){
	var hs = document.createElement('script');
	(document.getElementsByTagName('head')[0] || document.getElementsByTagName('body')[0]).appendChild(hs)
	hs.type = 'text/javascript';
	hs.async = true;
	hs.src = '//s10.histats.com/js15_as.js';
}, false);
</script>
<noscript><a href="/" target="_blank"><img  src="//sstatic1.histats.com/0.gif?4074658&101" alt="simple hit counter" border="0"></a></noscript>
</div></section><section id="text-5" class="widget widget_text"><h4 class="widget-title">Tautan</h4> <div class="textwidget"><div id="attachment_8" class="wp-caption aligncenter" style="width: 160px;">
<p><a href="http://banjarnegarakab.go.id/v3/"><img class="wp-image-8 size-thumbnail" src="https://klampok.id/wp-content/uploads/2018/05/logo-kabupaten-banjarnegara-150x150.png" alt="Pemerintah Banjarnegara" width="150" height="150" /></a></p>
<p class="wp-caption-text">Pemerintah Banjarnegara</p>
</div>
<div id="attachment_226" class="wp-caption aligncenter" style="width: 160px;">
<p><a href="http://budparbanjarnegara.com/"><img class="wp-image-226 size-thumbnail" src="https://klampok.id/wp-content/uploads/2018/05/Selection_004-150x150.png" alt="Dinas Pariwisata Banjarnegara" width="150" height="150" /></a></p>
<p class="wp-caption-text">Dinas Pariwisata Banjarnegara</p>
</div>
<div id="attachment_239" class="wp-caption aligncenter" style="width: 160px;">
<p><a href="http://kemendesa.go.id/"><img class="wp-image-239 size-thumbnail" src="https://klampok.id/wp-content/uploads/2018/05/logo-kementrian-desa-150x150.png" alt="Kementerian Desa" width="150" height="150" /></a></p>
<p class="wp-caption-text">Kementerian Desa</p>
</div>
</div>
</section><section id="recent-comments-2" class="widget widget_recent_comments"><h4 class="widget-title">Komentar Terbaru</h4><ul id="recentcomments"><li class="recentcomments"><span class="comment-author-link">admin</span> pada <a href="https://klampok.id/2019/03/rencana-kerja-panitia-pemilihan-kepala-desa-klampok-tahun-2019/#comment-264">RENCANA KERJA PANITIA PEMILIHAN KEPALA DESA KLAMPOK TAHUN 2019</a></li><li class="recentcomments"><span class="comment-author-link">wahyu</span> pada <a href="https://klampok.id/2019/03/rencana-kerja-panitia-pemilihan-kepala-desa-klampok-tahun-2019/#comment-247">RENCANA KERJA PANITIA PEMILIHAN KEPALA DESA KLAMPOK TAHUN 2019</a></li><li class="recentcomments"><span class="comment-author-link">wahyu</span> pada <a href="https://klampok.id/2019/03/rencana-kerja-panitia-pemilihan-kepala-desa-klampok-tahun-2019/#comment-246">RENCANA KERJA PANITIA PEMILIHAN KEPALA DESA KLAMPOK TAHUN 2019</a></li><li class="recentcomments"><span class="comment-author-link">admin</span> pada <a href="https://klampok.id/2019/03/rencana-kerja-panitia-pemilihan-kepala-desa-klampok-tahun-2019/#comment-245">RENCANA KERJA PANITIA PEMILIHAN KEPALA DESA KLAMPOK TAHUN 2019</a></li><li class="recentcomments"><span class="comment-author-link">admin</span> pada <a href="https://klampok.id/2019/03/rencana-kerja-panitia-pemilihan-kepala-desa-klampok-tahun-2019/#comment-244">RENCANA KERJA PANITIA PEMILIHAN KEPALA DESA KLAMPOK TAHUN 2019</a></li><li class="recentcomments"><span class="comment-author-link">admin</span> pada <a href="https://klampok.id/2019/03/panitia-pemilihan-kepala-desa-klampok-tahun-2019/#comment-243">PANITIA PEMILIHAN KEPALA DESA KLAMPOK TAHUN 2019</a></li><li class="recentcomments"><span class="comment-author-link">admin</span> pada <a href="https://klampok.id/2019/03/4-hal-yang-harus-dimiliki-perangkat-desa/#comment-242">4 HAL YANG HARUS DIKUASAI PERANGKAT DESA</a></li><li class="recentcomments"><span class="comment-author-link">admin</span> pada <a href="https://klampok.id/2019/03/4-hal-yang-harus-dimiliki-perangkat-desa/#comment-241">4 HAL YANG HARUS DIKUASAI PERANGKAT DESA</a></li><li class="recentcomments"><span class="comment-author-link">admin</span> pada <a href="https://klampok.id/2019/03/4-hal-yang-harus-dimiliki-perangkat-desa/#comment-240">4 HAL YANG HARUS DIKUASAI PERANGKAT DESA</a></li><li class="recentcomments"><span class="comment-author-link">wahyu</span> pada <a href="https://klampok.id/2019/03/4-hal-yang-harus-dimiliki-perangkat-desa/#comment-237">4 HAL YANG HARUS DIKUASAI PERANGKAT DESA</a></li></ul></section><section id="text-2" class="widget widget_text"> <div class="textwidget"><p>Jl. Raya Klampok Banjarnegara, No.95<br />
Desa Klampok, Kec. Purwareja Klampok<br />
Banjarnegara – Jawa Tengah<br />
Kode Pos 53474<br />
Telepon: (0286) 479608</p>
</div>
</section><section id="text-3" class="widget widget_text"> <div class="textwidget"><p><a href="https://klampok.id/hubungi/">Hubungi</a> | <a href="https://klampok.id/tentang-website-desa-klampok/">Tentang</a> | <a href="http://sid.klampok.id">Akses SID</a> | <a href="https://klampok.id/wp-admin/">Admin Web</a></p>
</div>
</section></aside>
</div>
</div>
<footer id="colophon" class="site-footer" role="contentinfo"><div class="bottom-footer np-clearfix"><div class="mt-container"> <div class="site-info">
<span class="np-copyright-text">
News Portal </span>
<span class="sep"> | </span>
Theme: News Portal by <a href="https://mysterythemes.com/" rel="designer" target="_blank">Mystery Themes</a>. </div>
<nav id="footer-navigation" class="footer-navigation" role="navigation">
</nav>
</div></div> </footer><div id="np-scrollup" class="animated arrow-hide"><i class="fa fa-chevron-up"></i></div></div>
<link rel='stylesheet' id='mediaelement-css' href='https://klampok.id/wp-includes/js/mediaelement/mediaelementplayer-legacy.min.css?ver=4.2.6-78496d1' type='text/css' media='all' />
<link rel='stylesheet' id='wp-mediaelement-css' href='https://klampok.id/wp-includes/js/mediaelement/wp-mediaelement.min.css?ver=5.1.1' type='text/css' media='all' />
<link rel='stylesheet' id='metaslider-nivo-slider-css' href='https://klampok.id/wp-content/plugins/ml-slider/assets/sliders/nivoslider/nivo-slider.css?ver=3.12.1' type='text/css' media='all' property='stylesheet' />
<link rel='stylesheet' id='metaslider-public-css' href='https://klampok.id/wp-content/plugins/ml-slider/assets/metaslider/public.css?ver=3.12.1' type='text/css' media='all' property='stylesheet' />
<link rel='stylesheet' id='metaslider-nivo-slider-default-css' href='https://klampok.id/wp-content/plugins/ml-slider/assets/sliders/nivoslider/themes/default/default.css?ver=3.12.1' type='text/css' media='all' property='stylesheet' />
<script type='text/javascript' src='https://klampok.id/wp-content/themes/news-portal/assets/js/navigation.js?ver=1.0.0'></script>
<script type='text/javascript' src='https://klampok.id/wp-content/themes/news-portal/assets/library/sticky/jquery.sticky.js?ver=20150416'></script>
<script type='text/javascript' src='https://klampok.id/wp-content/themes/news-portal/assets/library/sticky/sticky-setting.js?ver=20150309'></script>
<script type='text/javascript' src='https://klampok.id/wp-content/themes/news-portal/assets/js/skip-link-focus-fix.js?ver=1.0.0'></script>
<script type='text/javascript' src='https://klampok.id/wp-content/themes/news-portal/assets/library/lightslider/js/lightslider.min.js?ver=1.1.6'></script>
<script type='text/javascript' src='https://klampok.id/wp-includes/js/jquery/ui/core.min.js?ver=1.11.4'></script>
<script type='text/javascript' src='https://klampok.id/wp-includes/js/jquery/ui/widget.min.js?ver=1.11.4'></script>
<script type='text/javascript' src='https://klampok.id/wp-includes/js/jquery/ui/tabs.min.js?ver=1.11.4'></script>
<script type='text/javascript' src='https://klampok.id/wp-content/themes/news-portal/assets/js/np-custom-scripts.js?ver=1.0.0'></script>
<script type='text/javascript' src='https://klampok.id/wp-includes/js/wp-embed.min.js?ver=5.1.1'></script>
<script type='text/javascript'>
var mejsL10n = {"language":"id","strings":{"mejs.install-flash":"Anda menggunakan peramban yang tidak terinstal pemutar Flash. Silakan hidupkan plugin pemutar Flash Anda atau unduh versi terakhirnya dari https:\/\/get.adobe.com\/flashplayer\/","mejs.fullscreen-off":"Matikan Layar Penuh","mejs.fullscreen-on":"Nyalakan Layar Penuh","mejs.download-video":"Unduh Video","mejs.fullscreen":"Selayar penuh","mejs.time-jump-forward":["Loncat 1 detik ke depan","Maju %1 detik"],"mejs.loop":"Ganti Loop","mejs.play":"Putar","mejs.pause":"Jeda","mejs.close":"Tutup","mejs.time-slider":"Penggeser Waktu","mejs.time-help-text":"Gunakan tuts Panah Kanan\/Kiri untuk melompat satu detik, panah Atas\/Bawah untuk melompat sepuluh detik.","mejs.time-skip-back":["Putar balik 1 detik","Mundur %1 detik"],"mejs.captions-subtitles":"Subteks\/Subjudul","mejs.captions-chapters":"Bab","mejs.none":"Tak ada","mejs.mute-toggle":"Pengubah Sunyi","mejs.volume-help-text":"Gunakan Anak Panah Atas\/Bawah untuk menaikkan atau menurunkan volume.","mejs.unmute":"Matikan Sunyi","mejs.mute":"Bisu","mejs.volume-slider":"Penggeser Volume","mejs.video-player":"Pemutar Video","mejs.audio-player":"Pemutar Audio","mejs.ad-skip":"Lewati iklan","mejs.ad-skip-info":["Lewati %1 detik","Lewati %1 detik"],"mejs.source-chooser":"Pemilih Sumber","mejs.stop":"Berhenti","mejs.speed-rate":"Laju Kecepatan","mejs.live-broadcast":"Siaran Langsung","mejs.afrikaans":"Bahasa Afrikanas","mejs.albanian":"Bahasa Albania","mejs.arabic":"Bahasa Arab","mejs.belarusian":"Bahasa Belarusia","mejs.bulgarian":"Bahasa Bulgaria","mejs.catalan":"Bahasa Katalan","mejs.chinese":"Bahasa Mandarin","mejs.chinese-simplified":"Bahasa Mandarin (Disederhanakan)","mejs.chinese-traditional":"Bahasa Mandarin (Tradisional)","mejs.croatian":"Bahasa Kroasia","mejs.czech":"Bahasa Ceko","mejs.danish":"Bahasa Denmark","mejs.dutch":"Bahasa Belanda","mejs.english":"Bahasa Inggris","mejs.estonian":"Bahasa Estonia","mejs.filipino":"Bahasa Filipino","mejs.finnish":"Bahasa Finlandia","mejs.french":"Bahasa Perancis","mejs.galician":"Bahasa Galikan","mejs.german":"Bahasa Jerman","mejs.greek":"Bahasa Yunani","mejs.haitian-creole":"Bahasa Kreol Haiti","mejs.hebrew":"Bahasa Ibrani","mejs.hindi":"Bahasa Hindi","mejs.hungarian":"Bahasa Hungaria","mejs.icelandic":"Bahasa Islandia","mejs.indonesian":"Bahasa Indonesia","mejs.irish":"Bahasa Irlandia","mejs.italian":"Bahasa Italia","mejs.japanese":"Bahasa Jepang","mejs.korean":"Bahasa Korea","mejs.latvian":"Bahasa Latvia","mejs.lithuanian":"Bahasa Lithuania","mejs.macedonian":"Bahasa Macedonia","mejs.malay":"Bahasa Melayu","mejs.maltese":"Bahasa Malta","mejs.norwegian":"Bahasa Norwegia","mejs.persian":"Bahasa Persia","mejs.polish":"Bahasa Polandia","mejs.portuguese":"Bahasa Portugis","mejs.romanian":"Bahasa Romania","mejs.russian":"Bahasa Russia","mejs.serbian":"Bahasa Serbia","mejs.slovak":"Bahasa Slovakia","mejs.slovenian":"Bahasa Slovenia","mejs.spanish":"Bahasa Spanyol","mejs.swahili":"Bahasa Swahili","mejs.swedish":"Bahasa Swedia","mejs.tagalog":"Bahasa Tagalog","mejs.thai":"Bahasa Thai","mejs.turkish":"Bahasa Turki","mejs.ukrainian":"Bahasa Ukraina","mejs.vietnamese":"Bahasa Vietnam","mejs.welsh":"Bahasa Welsh","mejs.yiddish":"Bahasa Yiddi"}};
</script>
<script type='text/javascript' src='https://klampok.id/wp-includes/js/mediaelement/mediaelement-and-player.min.js?ver=4.2.6-78496d1'></script>
<script type='text/javascript' src='https://klampok.id/wp-includes/js/mediaelement/mediaelement-migrate.min.js?ver=5.1.1'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var _wpmejsSettings = {"pluginPath":"\/wp-includes\/js\/mediaelement\/","classPrefix":"mejs-","stretching":"responsive"};
/* ]]> */
</script>
<script type='text/javascript' src='https://klampok.id/wp-includes/js/mediaelement/wp-mediaelement.min.js?ver=5.1.1'></script>
<script type='text/javascript' src='https://klampok.id/wp-includes/js/mediaelement/renderers/vimeo.min.js?ver=4.2.6-78496d1'></script>
<script type='text/javascript' src='https://klampok.id/wp-content/plugins/ml-slider/assets/sliders/nivoslider/jquery.nivo.slider.pack.js?ver=3.12.1'></script>
<script type='text/javascript'>
var metaslider_199 = function($) {
            $('#metaslider_199').nivoSlider({ 
                boxCols:7,
                boxRows:5,
                pauseTime:3000,
                effect:"slideInRight",
                controlNav:false,
                directionNav:true,
                pauseOnHover:true,
                animSpeed:600,
                prevText:"Previous",
                nextText:"Next",
                slices:15,
                manualAdvance:false
            });
            $(document).trigger('metaslider/initialized', '#metaslider_199');
        };
        var timer_metaslider_199 = function() {
            var slider = !window.jQuery ? window.setTimeout(timer_metaslider_199, 100) : !jQuery.isReady ? window.setTimeout(timer_metaslider_199, 1) : metaslider_199(window.jQuery);
        };
        timer_metaslider_199();
</script>
</body>
</html>