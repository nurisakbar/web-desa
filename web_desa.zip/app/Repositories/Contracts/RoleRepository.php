<?php

namespace App\Repositories\Contracts;

interface RoleRepository
{
    //
}
