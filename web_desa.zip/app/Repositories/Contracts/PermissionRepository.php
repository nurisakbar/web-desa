<?php

namespace App\Repositories\Contracts;

interface PermissionRepository
{
    //
}
