<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class TarafKehidupan extends Model
{
    protected $table="taraf_kehidupan";

}
