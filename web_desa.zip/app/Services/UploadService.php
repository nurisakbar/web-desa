<?php

namespace App\Services;

class UploadService
{
    //
}
